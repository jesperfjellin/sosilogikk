from .sosilogikk import read_sosi_file, sosi_to_geodataframe
