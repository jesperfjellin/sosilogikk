

<div align="center">
  <img src="./images/sosilogikk.jpg" alt="Project Logo" width="400"/>
</div>

<div align="center">


  
</div>

---

Logikk for å bruke Python biblioteker som Geopandas, Shapely, Fiona etc på .SOS-filer. sosilogikk.py i mappen modules definerer en logikk for å bryte opp en .SOS-fil i objektsegmenter som kan lastes inn i en Geopandas dataframe. 
